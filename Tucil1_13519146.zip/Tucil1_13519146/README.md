# Tugas Kecil 1 Strategi Algoritma

## Penjelasan Program
Program dalam bahasa python untuk menyelesaikan Cryptarithmetic dengan algoritma brute force. Waktu eksekusi program tiap case dapat berbeda-beda tergantung dari kerumitan soal.

## Requirement
Python 3
Terminal

## Cara menggunakan program
1. Masuk ke dalam folder bin/src
2. Membuka terminal
3. Jalankan program dengan menuliskan python tucil.py atau python3 tucil.py pada terminal
4. Masukkan nama file yang akan di tes penyelesaiannya (misalnya saja case1.txt)
5. Tunggu saat program berjalan hingga program selesai melakukan eksekusinya (setiap test case akan menghasilkan waktu eksekusi yang berbeda, beberapa membutuhkan waktu yang sangat lama)

## Author
Fadel Ananda Dotty / 13519146
